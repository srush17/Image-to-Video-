
export interface Creator {
  name: string;
  role: string;
  email: string;
  instagram?: string;
  image: string;
}

export interface DemoItem {
  id: string;
  title: string;
  prompt: string;
  imageUrl: string;
  videoUrl: string;
}

export interface Template {
  id: string;
  name: string;
  type: 'IMAGE' | 'VIDEO';
  category: 'Cinematic' | 'Social' | 'Professional' | 'Artistic';
  prompt: string;
  thumbnail: string; // Gradient or color string for UI
  icon: string;
}

export interface User {
  name: string;
  avatar: string;
  plan: 'Free' | 'Pro';
}

export enum AppState {
  LANDING = 'LANDING',
  LOGIN = 'LOGIN',
  DASHBOARD = 'DASHBOARD'
}

export interface MotionConfig {
  intensity: 'low' | 'medium' | 'high';
  style: 'cinematic' | 'natural' | 'dynamic';
  resolution: '720p' | '1080p';
  slowMotion?: boolean;
}

export interface VideoGenerationState {
  status: 'idle' | 'uploading' | 'generating' | 'success' | 'error';
  progress?: number;
  resultUrl?: string;
  error?: string;
  config?: MotionConfig;
}
