
import React, { useState } from 'react';
import { TEMPLATES } from '../constants';
import { Template } from '../types';
import { Sparkles, LayoutTemplate, Film, Image as ImageIcon, Star } from 'lucide-react';

interface SidebarProps {
  onSelectTemplate: (template: Template) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onSelectTemplate }) => {
  const [activeTab, setActiveTab] = useState<'VIDEO' | 'IMAGE'>('VIDEO');

  const filteredTemplates = TEMPLATES.filter(t => t.type === activeTab);

  return (
    <aside className="w-72 bg-[#0B0F19] border-r border-white/5 flex flex-col h-full overflow-hidden shrink-0">
      
      {/* Category Tabs */}
      <div className="p-4 border-b border-white/5">
         <div className="flex bg-slate-900/50 p-1 rounded-xl">
            <button 
               onClick={() => setActiveTab('VIDEO')}
               className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === 'VIDEO' ? 'bg-violet-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
            >
               <Film size={14} /> Motion
            </button>
            <button 
               onClick={() => setActiveTab('IMAGE')}
               className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold transition-all ${activeTab === 'IMAGE' ? 'bg-teal-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
            >
               <ImageIcon size={14} /> Remix
            </button>
         </div>
      </div>

      {/* Templates List */}
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 px-1">
          {activeTab === 'VIDEO' ? 'Motion Templates' : 'Style Templates'}
        </h3>
        
        <div className="grid grid-cols-1 gap-3">
          {filteredTemplates.map((t) => (
            <button
              key={t.id}
              onClick={() => onSelectTemplate(t)}
              className="group relative h-24 rounded-xl overflow-hidden border border-white/5 hover:border-violet-500/50 transition-all text-left shadow-sm hover:shadow-violet-900/20"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${t.thumbnail} opacity-30 group-hover:opacity-60 transition-opacity`}></div>
              
              {/* Icon Overlay */}
              <div className="absolute right-2 bottom-2 opacity-10 group-hover:opacity-30 transform group-hover:scale-125 transition-all">
                  <LayoutTemplate size={40} />
              </div>

              <div className="absolute inset-0 p-3 flex flex-col justify-between z-10">
                 <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border border-white/10 backdrop-blur-sm ${t.type === 'VIDEO' ? 'bg-violet-500/20 text-violet-200' : 'bg-teal-500/20 text-teal-200'}`}>
                      {t.category}
                    </span>
                 </div>
                 <div>
                   <span className="block text-sm font-bold text-white group-hover:text-violet-100 transition-colors truncate">
                     {t.name}
                   </span>
                   <span className="block text-[10px] text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity truncate mt-1">
                     Click to apply preset
                   </span>
                 </div>
              </div>
            </button>
          ))}
        </div>

        <div className="mt-8 p-5 bg-gradient-to-b from-slate-900 to-black rounded-2xl border border-white/5 relative overflow-hidden group">
          <div className="absolute -top-10 -right-10 w-24 h-24 bg-violet-600/20 rounded-full blur-xl group-hover:bg-violet-600/30 transition-colors"></div>
          
          <div className="relative z-10">
            <div className="w-10 h-10 rounded-full bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center text-yellow-500 mb-3">
               <Star size={20} fill="currentColor" />
            </div>
            <h4 className="text-sm font-bold text-white mb-1">Unlock Pro Studio</h4>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">Get 4K rendering, 500+ templates, and priority GPU processing.</p>
            <button className="w-full py-2.5 bg-white text-slate-950 rounded-lg text-xs font-bold hover:bg-slate-200 transition-colors shadow-lg">
              Upgrade Plan
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
