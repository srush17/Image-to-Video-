import React from 'react';
import { Aperture, User, Bell, ChevronDown } from 'lucide-react';
import { CURRENT_USER, APP_NAME } from '../constants';

const Header: React.FC = () => {
  return (
    <header className="h-16 bg-slate-950 border-b border-white/5 flex items-center justify-between px-6 z-50">
      {/* Left: Branding & Logo */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 group cursor-pointer">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-600 to-teal-500 flex items-center justify-center shadow-lg shadow-violet-500/20 group-hover:shadow-violet-500/40 transition-all">
            <Aperture className="text-white animate-spin-slow" size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white tracking-tight leading-none brand-font">
              Motion AI
            </h1>
          </div>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center ml-10 space-x-1">
          <button className="px-4 py-2 text-sm font-medium text-white bg-white/5 rounded-lg border border-white/5">
            Design
          </button>
          <button className="px-4 py-2 text-sm font-medium text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
            Projects
          </button>
          <button className="px-4 py-2 text-sm font-medium text-slate-400 hover:text-white hover:bg-white/5 rounded-lg transition-colors">
            Team
          </button>
        </nav>
      </div>

      {/* Right: User Actions */}
      <div className="flex items-center gap-4">
        <button className="p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-full transition-colors relative">
          <Bell size={20} />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-slate-950"></span>
        </button>
        
        <div className="h-8 w-px bg-white/10 mx-1"></div>

        <div className="flex items-center gap-3 cursor-pointer hover:bg-white/5 p-1 pr-3 rounded-full transition-colors border border-transparent hover:border-white/5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-pink-500 to-orange-400 flex items-center justify-center text-xs font-bold text-white shadow-inner">
            {CURRENT_USER.avatar}
          </div>
          <div className="hidden lg:block text-left">
            <p className="text-xs font-bold text-white leading-tight">{CURRENT_USER.name}</p>
            <p className="text-[10px] text-emerald-400 font-medium">{CURRENT_USER.plan} Plan</p>
          </div>
          <ChevronDown size={14} className="text-slate-500" />
        </div>
      </div>
    </header>
  );
};

export default Header;