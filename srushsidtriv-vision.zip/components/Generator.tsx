
import React, { useState, useRef, useEffect } from 'react';
import { Upload, Film, Loader2, Sparkles, Image as ImageIcon, Download, RefreshCw, Play } from 'lucide-react';
import { generateVideo, generateImage, generateImageRemix } from '../services/geminiService';
import { VideoGenerationState, Template, MotionConfig } from '../types';

type Mode = 'IMAGE' | 'VIDEO';

interface GeneratorProps {
  selectedTemplate: Template | null;
}

const MotionPlayer: React.FC<{ spriteSheetUrl: string }> = ({ spriteSheetUrl }) => {
  const [frame, setFrame] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setFrame(prev => (prev + 1) % 4);
    }, 125); // 8fps
    return () => clearInterval(interval);
  }, []);

  const positions = [
    '0% 0%',   // Top Left
    '100% 0%', // Top Right
    '0% 100%', // Bottom Left
    '100% 100%' // Bottom Right
  ];

  return (
    <div 
      className="w-full h-full bg-no-repeat shadow-2xl rounded-lg"
      style={{
        backgroundImage: `url(${spriteSheetUrl})`,
        backgroundSize: '200% 200%',
        backgroundPosition: positions[frame],
        imageRendering: 'pixelated'
      }}
    />
  );
};

const Generator: React.FC<GeneratorProps> = ({ selectedTemplate }) => {
  const [mode, setMode] = useState<Mode>('IMAGE');
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  const [prompt, setPrompt] = useState<string>("");
  const [state, setState] = useState<VideoGenerationState>({ 
    status: 'idle',
    config: {
      intensity: 'medium',
      style: 'cinematic',
      resolution: '720p',
      slowMotion: false
    }
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Apply template when selected
  useEffect(() => {
    if (selectedTemplate) {
      setPrompt(selectedTemplate.prompt);
      setMode(selectedTemplate.type);
    }
  }, [selectedTemplate]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      if (selectedImages.length >= 3) return;

      setSelectedImages(prev => [...prev, file]);
      setImagePreviews(prev => [...prev, URL.createObjectURL(file)]);
      setState(prev => ({ ...prev, status: 'idle' }));
    }
    // Reset input
    if (e.target) e.target.value = '';
  };

  const removeImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
    setImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const handleGenerate = async () => {
    if (selectedImages.length === 0 || !prompt) return;

    setState(prev => ({ ...prev, status: 'generating', progress: 0 }));

    // Simulate progress for UI feedback
    const progressInterval = setInterval(() => {
      setState(prev => {
        if (prev.status !== 'generating') return prev;
        return { ...prev, progress: Math.min((prev.progress || 0) + 5, 99) };
      });
    }, 500);

    try {
      let resultUrl;
      if (mode === 'VIDEO') {
        resultUrl = await generateVideo(selectedImages, prompt, state.config);
      } else {
        resultUrl = await generateImageRemix(selectedImages, prompt, state.config);
      }
      
      clearInterval(progressInterval);
      setState(prev => ({ ...prev, status: 'success', resultUrl: resultUrl, progress: 100 }));

    } catch (error: any) {
      clearInterval(progressInterval);
      setState(prev => ({ 
        ...prev,
        status: 'error', 
        error: error.message || "Failed to generate."
      }));
    }
  };

  const handleExport = () => {
    if (state.status !== 'success' || !state.resultUrl) return;
    
    const link = document.createElement('a');
    const timestamp = new Date().getTime();
    link.href = state.resultUrl;
    const isImage = state.resultUrl.startsWith('data:image');
    link.download = `Motion_AI_${timestamp}.${isImage ? 'jpg' : 'mp4'}`;
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderCanvasContent = () => {
    if (state.status === 'success') {
      if (mode === 'VIDEO' && state.resultUrl) {
        return <MotionPlayer spriteSheetUrl={state.resultUrl} />;
      } else if (state.resultUrl) {
        return (
           <img 
            src={state.resultUrl} 
            alt="Result" 
            className="max-w-full max-h-full object-contain shadow-2xl rounded-lg"
          />
        );
      }
    }
    
    if (state.status === 'generating') {
      return (
        <div className="flex flex-col items-center justify-center space-y-6">
          <div className="relative">
             <div className="w-24 h-24 border-4 border-violet-500/20 border-t-violet-500 rounded-full animate-spin"></div>
             <div className="absolute inset-0 flex items-center justify-center">
                <Sparkles className="text-violet-400 animate-pulse" size={32} />
             </div>
          </div>
          <div className="text-center space-y-2">
            <p className="text-violet-300 font-bold text-lg tracking-wider uppercase animate-pulse">Synthesizing Reality</p>
            <p className="text-slate-500 text-xs uppercase tracking-widest">Applying temporal consistency & physics</p>
          </div>
          <div className="w-80 h-1.5 bg-slate-800 rounded-full overflow-hidden shadow-inner">
             <div className="h-full bg-gradient-to-r from-violet-600 to-indigo-600 transition-all duration-500 shadow-[0_0_15px_rgba(124,58,237,0.5)]" style={{ width: `${state.progress}%` }}></div>
          </div>
          <p className="text-slate-400 text-[10px] font-mono">{state.progress}% COMPLETE</p>
        </div>
      );
    }

    if (imagePreviews.length > 0) {
        return (
            <div className="relative w-full h-full flex items-center justify-center gap-6 p-8">
                 {imagePreviews.map((preview, idx) => (
                    <React.Fragment key={idx}>
                        <div className="flex-1 flex flex-col items-center gap-4 group/frame">
                            <div className="relative aspect-video w-full bg-slate-950 rounded-xl border border-white/5 overflow-hidden shadow-2xl ring-1 ring-white/10">
                                <img src={preview} alt={`Source ${idx + 1}`} className="w-full h-full object-cover opacity-80" />
                                <button 
                                    onClick={() => removeImage(idx)}
                                    className="absolute top-3 right-3 bg-red-500/80 hover:bg-red-500 p-1.5 rounded-lg opacity-0 group-hover/frame:opacity-100 transition-opacity"
                                >
                                    <RefreshCw size={12} className="text-white" />
                                </button>
                            </div>
                        </div>
                        {idx < imagePreviews.length - 1 && (
                            <div className="flex flex-col items-center text-slate-700">
                                <RefreshCw size={20} className="animate-spin-slow opacity-30" />
                            </div>
                        )}
                    </React.Fragment>
                 ))}
                 
                 {imagePreviews.length < 3 && mode === 'VIDEO' && (
                    <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="flex-1 aspect-video border-2 border-dashed border-slate-800 rounded-xl bg-slate-900/30 hover:bg-slate-800 hover:border-violet-500/50 transition-all cursor-pointer flex flex-col items-center justify-center group"
                    >
                        <Upload size={24} className="text-slate-600 group-hover:text-violet-400 mb-2" />
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 group-hover:text-slate-300">Add Frame {imagePreviews.length + 1}</span>
                    </div>
                 )}
            </div>
        )
    }

    return (
      <div className="text-center">
         <div className="w-32 h-32 bg-slate-900/50 border-2 border-dashed border-slate-800 rounded-[2.5rem] mx-auto flex items-center justify-center mb-8 relative group">
            <div className="absolute inset-0 bg-violet-500/5 rounded-[2.5rem] blur-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <ImageIcon size={48} className="text-slate-700 group-hover:text-violet-500 transition-colors" />
         </div>
         <h3 className="text-xl font-bold text-slate-300 mb-3 tracking-tight">Ready to Generate</h3>
         <p className="text-slate-500 text-sm max-w-xs mx-auto leading-relaxed">
            Upload images and describe the movement you want to see.
         </p>
      </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#020617] overflow-hidden">
        {/* Toolbar */}
        <div className="h-16 border-b border-white/5 bg-[#0B0F19] flex items-center justify-between px-6 shrink-0 z-20 shadow-lg">
            <div className="flex items-center space-x-2 bg-slate-900/50 p-1 rounded-xl border border-white/5">
                <button 
                  onClick={() => setMode('IMAGE')}
                  className={`px-5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${mode === 'IMAGE' ? 'bg-teal-600 text-white shadow-lg shadow-teal-900/20' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                >
                    <ImageIcon size={14} /> Free Remix
                </button>
                <button 
                  onClick={() => setMode('VIDEO')}
                  className={`px-5 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-2 ${mode === 'VIDEO' ? 'bg-violet-600 text-white shadow-lg shadow-violet-900/20' : 'text-slate-400 hover:text-white hover:bg-white/5'}`}
                >
                    <Film size={14} /> Realistic Motion
                </button>
            </div>

            <div className="flex items-center gap-3">
                <div className="hidden sm:flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Fast Engine Active</span>
                </div>
                <div className="h-8 w-px bg-white/10 mx-1"></div>
                <button 
                    onClick={handleExport}
                    disabled={state.status !== 'success'}
                    className={`px-6 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${state.status === 'success' ? 'bg-white text-slate-950 hover:bg-slate-200 shadow-[0_0_20px_rgba(255,255,255,0.1)]' : 'bg-white/5 text-slate-500 cursor-not-allowed'}`}
                >
                    <Download size={14} /> Download 4K
                </button>
            </div>
        </div>

        {/* Workspace Content */}
        <div className="flex-1 flex overflow-hidden">
            {/* Left Controls Panel */}
            <div className="w-[26rem] bg-[#0B0F19] border-r border-white/5 p-6 flex flex-col overflow-y-auto custom-scrollbar">
                
                {/* Upload Section */}
                <div className="mb-8">
                    <div className="flex items-center justify-between mb-4">
                        <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Source Material</h3>
                        <div className="flex gap-1">
                            <div className={`w-1.5 h-1.5 rounded-full ${selectedImages.length > 0 ? 'bg-emerald-500 animate-pulse' : 'bg-slate-700'}`}></div>
                            <span className={`text-[8px] font-bold uppercase tracking-widest ${selectedImages.length > 0 ? 'text-emerald-500' : 'text-slate-600'}`}>
                                {selectedImages.length > 0 ? 'Frames Loaded' : 'Waiting'}
                            </span>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-2">
                        {imagePreviews.map((preview, idx) => (
                            <div key={idx} className="relative h-24 rounded-xl overflow-hidden border border-white/10 group">
                                <img src={preview} className="w-full h-full object-cover" />
                                <button 
                                    onClick={() => removeImage(idx)}
                                    className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
                                >
                                    <RefreshCw size={14} className="text-white" />
                                </button>
                            </div>
                        ))}
                        
                        {imagePreviews.length < 3 && (
                            <div 
                                onClick={() => fileInputRef.current?.click()}
                                className="h-24 border border-dashed border-slate-700 rounded-xl bg-slate-900/30 hover:bg-slate-800 hover:border-violet-500/50 transition-all cursor-pointer flex flex-col items-center justify-center group"
                            >
                                <Upload size={18} className="text-slate-600 group-hover:text-violet-400 mb-1" />
                                <span className="text-[8px] font-bold text-slate-500 uppercase">Add Frame</span>
                            </div>
                        )}
                    </div>
                    
                    <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
                </div>

                {/* Prompt Section */}
                <div className="mb-6 flex flex-col min-h-0">
                    <div className="flex items-center justify-between mb-3">
                        <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Synthesis Prompt</h3>
                    </div>
                    <textarea 
                        value={prompt}
                        onChange={(e) => setPrompt(e.target.value)}
                        placeholder={mode === 'VIDEO' ? "Describe the ACTUAL MOVEMENT (e.g., 'A person dancing, moving hands and head gestures')..." : "Describe the visual remix..."}
                        className="w-full h-48 bg-slate-950 border border-white/5 rounded-2xl p-5 text-sm text-white placeholder:text-slate-700 focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20 outline-none resize-none transition-all shadow-inner custom-scrollbar"
                    />
                </div>

                <div className="mt-auto shrink-0 space-y-4">
                    <button
                        onClick={handleGenerate}
                        disabled={selectedImages.length === 0 || !prompt || state.status === 'generating'}
                        className={`w-full py-5 rounded-2xl font-bold text-xs tracking-[0.2em] uppercase flex items-center justify-center space-x-3 transition-all shadow-2xl relative overflow-hidden group ${
                            selectedImages.length === 0 || !prompt 
                            ? 'bg-slate-900 text-slate-600 cursor-not-allowed border border-white/5' 
                            : state.status === 'generating'
                                ? 'bg-slate-800 text-white cursor-wait'
                                : 'bg-white text-slate-950 hover:bg-slate-100 transform hover:-translate-y-1 active:translate-y-0'
                        }`}
                    >
                        {state.status === 'generating' ? (
                            <Loader2 className="animate-spin" size={18} />
                        ) : (
                            <Play size={16} fill="currentColor" />
                        )}
                        <span>{state.status === 'generating' ? 'Synthesizing...' : mode === 'IMAGE' ? 'Generate Remix' : 'Generate Realistic Motion'}</span>
                        
                        {state.status !== 'generating' && selectedImages.length > 0 && prompt && (
                            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-shimmer"></div>
                        )}
                    </button>
                    
                    {state.error && (
                         <div className="mt-4 p-5 bg-red-500/10 border border-red-500/20 rounded-2xl flex flex-col gap-4 text-red-400 text-[11px] leading-relaxed shadow-lg">
                            <div className="flex items-start gap-3">
                                <div className="mt-1 w-2 h-2 rounded-full bg-red-500 shrink-0 shadow-[0_0_10px_rgba(239,68,68,0.5)]"></div>
                                <div className="space-y-1">
                                    <p className="font-bold uppercase tracking-wider text-red-300">Generation Error</p>
                                    <p className="text-red-400/80">{state.error}</p>
                                </div>
                            </div>
                         </div>
                    )}
                </div>
            </div>

            {/* Right Canvas Area */}
            <div className="flex-1 bg-[#050811] relative flex flex-col">
                <div className="flex-1 flex items-center justify-center p-12 overflow-hidden relative">
                    {/* Background Effects */}
                    <div className="absolute inset-0 opacity-[0.02] pointer-events-none" 
                        style={{ backgroundImage: 'linear-gradient(#4b5563 1px, transparent 1px), linear-gradient(90deg, #4b5563 1px, transparent 1px)', backgroundSize: '60px 60px' }}>
                    </div>
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-violet-600/5 rounded-full blur-[120px] pointer-events-none"></div>
                    
                    {/* The Canvas */}
                    <div className="relative w-full max-w-5xl aspect-video bg-slate-950 rounded-3xl border border-white/5 shadow-[0_0_100px_rgba(0,0,0,0.5)] flex items-center justify-center overflow-hidden ring-1 ring-white/10 group">
                        {renderCanvasContent()}
                        
                        {/* Status Overlay */}
                        {state.status === 'success' && (
                            <div className="absolute bottom-6 right-6 flex items-center gap-2 bg-black/60 backdrop-blur-xl px-3 py-1.5 rounded-full border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
                                <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                                <span className="text-[10px] font-bold uppercase tracking-widest text-white">4K Render Complete</span>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Generator;
