
import React from 'react';
import { CREATORS } from '../constants';
import { ArrowRight, Aperture, PlayCircle } from 'lucide-react';

interface HeroProps {
  onStart: () => void;
}

const Hero: React.FC<HeroProps> = ({ onStart }) => {
  return (
    <div className="min-h-screen bg-[#020617] text-white relative overflow-y-auto">
       {/* Cinematic Background Gradient */}
       <div className="fixed inset-0 z-0 opacity-40">
           <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-violet-900/30 rounded-full blur-[150px]"></div>
           <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-teal-900/20 rounded-full blur-[150px]"></div>
       </div>

       <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 flex flex-col items-center justify-center min-h-screen">
          
          {/* Logo Badge */}
          <div className="mb-8 animate-fade-in-up">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-md">
                 <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></span>
                 <span className="text-xs font-bold uppercase tracking-widest text-teal-400">Final Year Project 2025-26</span>
              </div>
          </div>

          {/* Big Title */}
          <h1 className="text-6xl md:text-8xl font-bold text-center mb-6 tracking-tighter brand-font leading-none">
             SrushSidTriv <br />
             <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 via-fuchsia-400 to-teal-400">Vision Studio</span>
          </h1>

          <p className="text-xl text-slate-400 text-center max-w-2xl mb-12 leading-relaxed">
             Transform static images into hyper-realistic videos using advanced AI motion synthesis. 
             Experience the future of generative media.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col md:flex-row gap-6 mb-20">
             <button 
                onClick={onStart}
                className="group relative px-8 py-4 bg-white text-slate-950 rounded-full font-bold text-lg hover:bg-slate-200 transition-all flex items-center gap-3 shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)] hover:shadow-[0_0_60px_-10px_rgba(255,255,255,0.5)]"
             >
                Launch Studio
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
             </button>
             <button className="px-8 py-4 bg-slate-900/50 text-white border border-white/10 rounded-full font-bold text-lg hover:bg-slate-900 transition-all flex items-center gap-3 backdrop-blur-sm">
                <PlayCircle />
                Watch Demo
             </button>
          </div>

          {/* Creators Section (Inline) */}
          <div className="w-full border-t border-white/5 pt-16">
             <h3 className="text-center text-sm font-bold uppercase tracking-widest text-slate-500 mb-10">Project Created By</h3>
             <div className="flex flex-wrap justify-center gap-10">
                {CREATORS.map((c, i) => (
                   <div key={i} className="flex flex-col items-center text-center group">
                      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-slate-700 flex items-center justify-center text-xl font-bold mb-4 group-hover:border-violet-500 transition-colors shadow-lg">
                         {c.name.split(' ').map(n=>n[0]).join('')}
                      </div>
                      <h4 className="text-lg font-bold text-white">{c.name}</h4>
                      <p className="text-xs text-violet-400 font-medium">{c.role}</p>
                   </div>
                ))}
             </div>
          </div>

       </div>
    </div>
  );
};

export default Hero;
