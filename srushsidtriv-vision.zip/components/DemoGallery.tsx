import React from 'react';
import { DEMO_ITEMS } from '../constants';
import { Play } from 'lucide-react';

const DemoGallery: React.FC = () => {
  return (
    <div className="py-12">
       <div className="max-w-6xl mx-auto px-4">
         <div className="mb-8 text-center">
           <h2 className="text-3xl font-bold mb-3 brand-font">Live Demonstration</h2>
           <p className="text-slate-400">See what SrushSidTriv Vision can do with static images.</p>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           {DEMO_ITEMS.map((item) => (
             <div key={item.id} className="glass-panel rounded-2xl overflow-hidden group hover:border-violet-500/40 transition-all">
                <div className="aspect-video bg-slate-900 relative overflow-hidden">
                   {/* In a real app, we would likely show the video on hover or click. 
                       For this simulated demo, we use the image with a play overlay. */}
                   <img 
                    src={item.imageUrl} 
                    alt={item.title} 
                    className="w-full h-full object-cover opacity-80 group-hover:opacity-60 transition-opacity"
                   />
                   <div className="absolute inset-0 flex items-center justify-center">
                     <div className="w-16 h-16 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:scale-110 transition-transform cursor-pointer border border-white/20">
                        <Play fill="white" className="text-white ml-1" />
                     </div>
                   </div>
                   <div className="absolute top-2 right-2 bg-black/60 px-2 py-1 rounded text-xs text-white font-mono">
                     DEMO
                   </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-white text-lg">{item.title}</h3>
                  <div className="mt-3 p-3 bg-slate-900/50 rounded-lg border border-slate-800">
                    <p className="text-xs text-slate-500 uppercase font-bold mb-1">Input Prompt:</p>
                    <p className="text-sm text-violet-200 italic">"{item.prompt}"</p>
                  </div>
                </div>
             </div>
           ))}
         </div>
       </div>
    </div>
  );
};

export default DemoGallery;