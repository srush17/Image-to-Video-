import React from 'react';
import { CREATORS } from '../constants';
import { Mail, Instagram } from 'lucide-react';

const Creators: React.FC = () => {
  // Helper to get initials
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div id="creators" className="w-full py-16 px-4 bg-slate-950 relative overflow-hidden border-b border-slate-800">
      <div className="max-w-5xl mx-auto relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3 brand-font text-white">Project Creators</h2>
          <div className="w-16 h-1 bg-gradient-to-r from-violet-600 to-teal-600 mx-auto rounded-full"></div>
        </div>

        <div className="flex flex-wrap justify-center gap-10">
          {CREATORS.map((creator, index) => (
            <div 
              key={index} 
              className="flex flex-col items-center text-center group w-56 p-6 rounded-3xl bg-slate-900/40 border border-slate-800 hover:border-violet-500/30 transition-all duration-300 hover:bg-slate-900/80"
            >
              <div className="relative w-24 h-24 mb-5 rounded-full flex items-center justify-center bg-gradient-to-br from-slate-800 to-slate-900 ring-4 ring-slate-800 group-hover:ring-violet-500/50 transition-all duration-300 shadow-xl">
                {creator.image ? (
                  <img src={creator.image} alt={creator.name} className="w-full h-full rounded-full object-cover" />
                ) : (
                  <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-br from-violet-400 to-teal-400 tracking-wider">
                    {getInitials(creator.name)}
                  </span>
                )}
              </div>
              
              <h3 className="text-xl font-bold text-white mb-1">{creator.name}</h3>
              <p className="text-xs text-slate-400 font-medium mb-4 uppercase tracking-wider">{creator.role}</p>

              <div className="flex space-x-4 mt-auto opacity-70 group-hover:opacity-100 transition-opacity">
                <a href={`mailto:${creator.email}`} className="text-slate-400 hover:text-white transition-colors bg-slate-800/50 p-2 rounded-full hover:bg-violet-600">
                  <Mail size={16} />
                </a>
                {creator.instagram && (
                  <a href={`https://instagram.com/${creator.instagram}`} target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-white transition-colors bg-slate-800/50 p-2 rounded-full hover:bg-pink-600">
                    <Instagram size={16} />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Creators;
