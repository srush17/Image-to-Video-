
import { Creator, DemoItem, Template, User } from './types';

export const APP_NAME = "SrushSidTriv Vision Studio";
export const TAGLINE = "Three minds. One motion.";

export const CREATORS: Creator[] = [
  {
    name: "Srushti Bankar",
    role: "AI Model Architect",
    email: "srushtibankar17@gamil.com",
    instagram: "srush_17_",
    image: ""
  },
  {
    name: "Siddhi Mohite",
    role: "UI/UX Designer",
    email: "siddhi.mohite@example.com", 
    image: ""
  },
  {
    name: "Triveni Nalawade",
    role: "Backend Engineer",
    email: "triveni.nalawade@example.com", 
    image: ""
  }
];

export const TEMPLATES: Template[] = [
  // --- VIDEO TEMPLATES ---
  {
    id: 'v1',
    name: 'TikTok Dance Trend',
    type: 'VIDEO',
    category: 'Social',
    prompt: 'Person dancing with energetic hip-hop hand gestures, body grooving to the beat, dynamic camera movement, trending social media style.',
    thumbnail: 'from-pink-500 to-rose-600',
    icon: 'Music2'
  },
  {
    id: 'v2',
    name: 'Professional Speech',
    type: 'VIDEO',
    category: 'Professional',
    prompt: 'Person speaking naturally in a studio, hand gestures emphasizing points, slight head nod, professional corporate setting.',
    thumbnail: 'from-blue-600 to-slate-800',
    icon: 'Mic'
  },
  {
    id: 'v3',
    name: 'Cinematic Slow-Mo Walk',
    type: 'VIDEO',
    category: 'Cinematic',
    prompt: 'Person walking towards camera in slow motion, hair flowing in wind, dramatic sunset lighting, epic movie scene.',
    thumbnail: 'from-amber-600 to-orange-800',
    icon: 'Film'
  },
  {
    id: 'v4',
    name: 'Fashion Runway',
    type: 'VIDEO',
    category: 'Professional',
    prompt: 'Fashion model walking on runway, confident stride, camera flash photography effects, high fashion lighting.',
    thumbnail: 'from-violet-600 to-purple-900',
    icon: 'Aperture'
  },
  {
    id: 'v5',
    name: 'Laughing & Waving',
    type: 'VIDEO',
    category: 'Social',
    prompt: 'Person laughing joyfully and waving hand at camera, natural candid moment, bright lighting.',
    thumbnail: 'from-yellow-400 to-orange-500',
    icon: 'Smile'
  },
  {
    id: 'v6',
    name: 'Cyberpunk Glitch',
    type: 'VIDEO',
    category: 'Artistic',
    prompt: 'Cyberpunk character with neon lighting, glitch effects, robotic head movement, futuristic city background.',
    thumbnail: 'from-cyan-500 to-blue-600',
    icon: 'Zap'
  },

  // --- IMAGE TEMPLATES ---
  {
    id: 'i1',
    name: 'Studio Lighting Fix',
    type: 'IMAGE',
    category: 'Professional',
    prompt: 'Enhance lighting to professional studio quality, softbox lighting, remove shadows from face, 8k resolution.',
    thumbnail: 'from-slate-700 to-slate-900',
    icon: 'Sun'
  },
  {
    id: 'i2',
    name: 'Neon Retrowave',
    type: 'IMAGE',
    category: 'Artistic',
    prompt: 'Apply 80s retrowave aesthetic, neon purple and blue lights, grid background, synthwave style.',
    thumbnail: 'from-fuchsia-600 to-purple-800',
    icon: 'Palette'
  },
  {
    id: 'i3',
    name: 'Corporate Headshot',
    type: 'IMAGE',
    category: 'Professional',
    prompt: 'Change background to blurred modern office, professional suit attire, confident expression, linkedin profile style.',
    thumbnail: 'from-blue-800 to-slate-900',
    icon: 'Briefcase'
  },
  {
    id: 'i4',
    name: 'Fantasy Portrait',
    type: 'IMAGE',
    category: 'Artistic',
    prompt: 'Transform into a fantasy character, ethereal glow, magical particles, forest background, dreamlike quality.',
    thumbnail: 'from-emerald-500 to-teal-800',
    icon: 'Sparkles'
  },
  {
    id: 'i5',
    name: 'Anime Transformation',
    type: 'IMAGE',
    category: 'Artistic',
    prompt: 'Convert to high quality anime style, Studio Ghibli art style, vibrant colors, detailed line art.',
    thumbnail: 'from-red-500 to-orange-600',
    icon: 'Brush'
  },
  {
    id: 'i6',
    name: 'Background Removal',
    type: 'IMAGE',
    category: 'Professional',
    prompt: 'Isolate the subject, remove background completely, pure white background, clean edges.',
    thumbnail: 'from-gray-300 to-gray-500',
    icon: 'Scissors'
  }
];

export const CURRENT_USER: User = {
  name: "Guest User",
  avatar: "GU",
  plan: "Free"
};

export const DEMO_ITEMS: DemoItem[] = []; 
