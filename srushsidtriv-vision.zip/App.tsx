
import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Generator from './components/Generator';
import Hero from './components/Hero';
import Login from './components/Login';
import { Template, AppState } from './types';

const App: React.FC = () => {
  const [view, setView] = useState<AppState>(AppState.LANDING);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);

  // --- Render Views ---

  if (view === AppState.LANDING) {
    return <Hero onStart={() => setView(AppState.LOGIN)} />;
  }

  if (view === AppState.LOGIN) {
    return <Login onLoginSuccess={() => setView(AppState.DASHBOARD)} />;
  }

  // --- Dashboard View ---
  return (
    <div className="h-screen w-screen bg-[#020617] text-white flex flex-col font-sans overflow-hidden">
      <Header />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar onSelectTemplate={(t) => setSelectedTemplate(t)} />
        <main className="flex-1 relative flex flex-col min-w-0">
           <Generator selectedTemplate={selectedTemplate} />
        </main>
      </div>

      <div className="h-6 bg-slate-950 border-t border-white/5 flex items-center justify-between px-4 text-[9px] text-slate-600 z-50 shrink-0 uppercase tracking-wider">
         <span>Motion AI Studio © 2026</span>
         <span>Professional Video Synthesis Engine</span>
      </div>
    </div>
  );
};

export default App;
