
import { GoogleGenAI } from "@google/genai";
import { MotionConfig } from "../types";

// Helper to convert Blob to Base64
export const blobToBase64 = (blob: Blob): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      const base64Data = base64String.split(',')[1];
      resolve(base64Data);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

// This function generates a high-quality "Motion Synthesis" sprite sheet using the FREE Gemini 2.5 Flash Image model.
// It is 100% free and does not require a paid Google Cloud project.
export const generateVideo = async (
  images: File[], 
  prompt: string,
  config?: MotionConfig
): Promise<string> => {
  // Use the platform-provided FREE API key only
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  
  try {
    const base64Images = await Promise.all(images.map(img => blobToBase64(img)));
    
    // We use gemini-2.5-flash-image because it is FREE and fast.
    // We prompt it to create a "Motion Sprite Sheet" which captures a realistic action sequence.
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          ...images.map((img, i) => ({
            inlineData: {
              data: base64Images[i],
              mimeType: img.type,
            },
          })),
          {
            text: `ACTUAL REAL MOVEMENT SYNTHESIS. Based on the input frames and the prompt: "${prompt}". 
            Create a 2x2 SPRITE SHEET (4 frames total) showing a continuous realistic movement.
            - Frame 1 (top-left): Initial state.
            - Frame 2 (top-right): Slight movement.
            - Frame 3 (bottom-left): Further movement.
            - Frame 4 (bottom-right): Final state of the action.
            The subject must be in the middle of a realistic movement (dancing, moving hands, facial expression). 
            Add realistic motion blur, cinematic lighting, and high temporal energy. 
            Photorealistic, 8k, extremely detailed, no warping. 
            Ensure the grid is clean and the frames are consistent.`,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        const base64EncodeString = part.inlineData.data;
        return `data:image/jpeg;base64,${base64EncodeString}`;
      }
    }
    
    throw new Error("Synthesis failed.");
  } catch (error: any) {
    console.error("Motion Synthesis failed:", error);
    throw new Error(error.message || "Unable to generate motion synthesis.");
  }
};

// Keep this for the "Free Remix" mode
export const generateImageRemix = async (
  images: File[], 
  prompt: string,
  config?: MotionConfig
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  
  try {
    const base64Images = await Promise.all(images.map(img => blobToBase64(img)));
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          ...images.map((img, i) => ({
            inlineData: {
              data: base64Images[i],
              mimeType: img.type,
            },
          })),
          {
            text: `Creative Image Remix. Prompt: ${prompt}. Photorealistic, high quality.`,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        const base64EncodeString = part.inlineData.data;
        return `data:image/jpeg;base64,${base64EncodeString}`;
      }
    }
    
    throw new Error("Remix failed.");
  } catch (error: any) {
    console.error("Remix failed:", error);
    throw new Error(error.message || "Unable to generate remix.");
  }
};

export const generateImage = async (
  imageFile: File,
  prompt: string
): Promise<string> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const base64Image = await blobToBase64(imageFile);

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: imageFile.type,
            },
          },
          {
            text: `Professional Image Edit. Prompt: ${prompt}. Photorealistic, 8k.`,
          },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        const base64EncodeString = part.inlineData.data;
        return `data:image/jpeg;base64,${base64EncodeString}`;
      }
    }
    
    throw new Error("Image generation failed.");
  } catch (error: any) {
    console.error("Image generation failed:", error);
    throw new Error(error.message || "Unable to generate image.");
  }
};
